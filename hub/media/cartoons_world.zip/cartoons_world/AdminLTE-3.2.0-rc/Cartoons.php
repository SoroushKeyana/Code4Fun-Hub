<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | DataTables</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<?php
$serverName = "localhost";
$databaseName = "cartoons2";
$userName = "root";
$password = "";
$connection = mysqli_connect($serverName, $userName, $password, $databaseName);

if (!$connection) {
  echo mysqli_connect_errno();
  die();
}

$perpage = 5;

// Calculate total pages
$select_cartoon_query = "SELECT COUNT(*) as total FROM `cartoons`";
$total_record_result = mysqli_query($connection, $select_cartoon_query);
$total_record = mysqli_fetch_assoc($total_record_result)['total'];
$totalpages = ceil($total_record / $perpage);

// Get current page
$pageNum = isset($_GET['pageNum']) ? $_GET['pageNum'] : 1;
$start = ($pageNum - 1) * $perpage;

$searchKey = isset($_GET['search_key']) ? mysqli_real_escape_string($connection, $_GET['search_key']) : '';
$searchCondition = !empty($searchKey) ? "WHERE `cart_name` LIKE '%$searchKey%'" : '';
$paginationquery = "SELECT * FROM `cartoons` $searchCondition LIMIT $start, $perpage";
$result = mysqli_query($connection, $paginationquery);
?>


<body class="hold-transition sidebar-mini">

  <body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

      <!-- Preloader -->
      <div class="preloader flex-column justify-content-center align-items-center">
        <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
      </div>


      <?php
      include "include/navbar.php";
      include "include/sidebar.php"
      ?>


      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">

            <div class="">
              <h1 class="m-0">Cartoons</h1>

              <div class="card ">
                <div class="card-header">
                      <a href="add-cartoon.php" class="btn btn-success mx-3 ">Add New Cartoons</a>
                </div>
                <!-- /.card-header -->
                <div class="card-body">

                  <div class="row">
                    <div class="col-md-4 offset-md-8 mb-3">
                      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
                        <div class="input-group">
                          <input type="search" class="form-control form-control-lg" placeholder="Type your keywords here" name="search_key">
                          <div class="input-group-append">

                            <button type="submit" class="btn btn-lg btn-default" name="search_btn">
                              <i class="fa fa-search"></i>
                            </button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <table id="" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Photo</th>
                      </tr>
                    </thead>
                    <!--body-->
                    <tbody>
                      <?php
                      $num = ($pageNum - 1) * $perpage + 1;
                      while ($a = mysqli_fetch_assoc($result)) {
                      ?>
                        <tr>
                          <td><?= $num ?></td>
                          <td><?= $a['cart_name'] ?></td>
                          <td>
                            <!-- <a href="uploaded-files/<?= $a['cart-photo'] ?>"><?= $a['cart-photo'] ?></a> -->
                            <img src="uploaded-files/<?= $a['cart-photo'] ?>" style="width:100px">
                          </td>
                          <td>
                            <a href="edit-cartoon.php?cartoon_id=<?= $a['cart _id'] ?>" class="btn btn-dark">edit</a>
                            <a href="cartoon-delete.php?cartoon_id=<?= $a['cart _id'] ?>&img=<?= $a['cart-photo'] ?>" class="btn btn-danger" onclick="javascript:return confirm('Are You Sure.');">delete</a>
                          </td>
                        </tr>
                      <?php
                        $num++;
                      }
                      ?>
                    </tbody>
                    <tfoot>
                    </tfoot>
                  </table>
                  <ul class="pagination mt-3">
                    <?php
                    $a = 1;
                    while ($a <= $totalpages) {
                      $activeClass = ($a == $pageNum) ? 'active' : '';
                      $searchKeyParam = isset($_GET['search_key']) ? "&search_key=" . urlencode($_GET['search_key']) : '';
                      echo "<li class='page-item $activeClass'><a href=\"Cartoons.php?pageNum=$a$searchKeyParam\" class='p-1 m-1 page-link'>$a</a></li>";
                      $a++;
                    }
                    ?>
                  </ul>

                </div>
                <!-- /.card-body -->
              </div>
            </div>


          </div><!-- /.container-fluid -->
        </div>
      </div>
      <!-- /.content-wrapper -->
      <?php
      include "include/footer.php"

      ?>

      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
      </aside>
      <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables  & Plugins -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="plugins/jszip/jszip.min.js"></script>
    <script src="plugins/pdfmake/pdfmake.min.js"></script>
    <script src="plugins/pdfmake/vfs_fonts.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="plugins/sweetalert2/sweetalert2.min.js"></script>
    <!-- Toastr -->
    <script src="plugins/toastr/toastr.min.js"></script>

    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
      $(function() {
        $("#example1").DataTable({
          "responsive": true,
          "lengthChange": false,
          "autoWidth": false,
          "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "responsive": true,
        });
      });
    </script>


    <script>
      $(function() {
        var Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
        });

        <?php
        if (isset($_GET['msg'])) {


        ?>
          Toast.fire({
            icon: 'success',
            title: 'data inserted successfuly'
          });

        <?php


        }
        ?>

        <?php
        if (isset($_GET['deletemsg'])) {


        ?>
          Toast.fire({
            icon: 'success',
            title: 'data deleted successfuly'
          });

        <?php


        }
        ?>

        <?php
        if (isset($_GET['updmsg'])) {


        ?>
          Toast.fire({
            icon: 'success',
            title: 'data updated successfuly'
          });

        <?php


        }
        ?>


      });
    </script>


  </body>

</html>