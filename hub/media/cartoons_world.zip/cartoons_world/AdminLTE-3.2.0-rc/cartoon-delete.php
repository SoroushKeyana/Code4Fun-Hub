<?php
$serverName = "localhost";
$databaseName = "cartoons2";
$userName = "root";
$password = "";
 $connection = mysqli_connect($serverName , $userName ,$password ,$databaseName);
 if (!$connection){
  echo mysqli_connect_errno();
  die();
 }

$cartoonID= $_GET['cartoon_id'];
$img = $_GET['img'];


//echo 'uploaded-files/ ' . $_GET['img'];
//die();


unlink('uploaded-files/' . $img );
$deleteQuery = "delete from cartoons where `cart _id` = $cartoonID";

$delete = mysqli_query($connection , $deleteQuery);

if ($delete){
  header("location:cartoons.php?deletemsg=deleted");

}else{
  echo "not insserted";
  die();
}
?>
