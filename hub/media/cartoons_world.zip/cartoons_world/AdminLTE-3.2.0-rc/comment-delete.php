<?php
$serverName = "localhost";
$databaseName = "cartoons2";
$userName = "root";
$password = "";
 $connection = mysqli_connect($serverName , $userName ,$password ,$databaseName);
 if (!$connection){
  echo mysqli_connect_errno();
  die();
 }

$comment = $_GET['cart_id'];
$deletequery = "delete from `comments` where comm_id= $comment";

 $deletecom = mysqli_query($connection , $deletequery);

 if ( $deletecom){
  header("location:comment.php?deletmsg=deleted");

    }else{
      echo "not insserted";
      die();
    }

?>
